# REFRAMING (draft promoted for working tree; STOP 1)

This file mirrors `Documents/Codex/2026-10-28/final_draft_phase0/phase5_drafts/REFRAMING_DRAFT.md`.
**Status: DRAFT — recommendations not yet applied to `main.tex`.**

See the Codex draft for full dual framings. Headline item for STOP 1:

## Expert beats TARE (pilot C/B = 1.627)

Hostile weakness stated plainly: on sizing pilot 13534260, TARE was slower than the semantic expert (C/B=1.627; band was 1.1–1.6). Expert arm was **not** weakened. Paper must keep this visible; preferred non-obvious framing is the exact-vs-unchecked design rule (pay for the certificate, or ship B). Campaign C/B still unmeasured — pilot is not the G4 headline.
